<?php

namespace UnknowG\WapyPractice\utils;

class Colors{
    public const BLACK = "§0";
    public const DARK_GREEN = "§2";
    public const DARK_RED = "§4";
    public const GOLD = "§g";
    public const ORANGE = "§6";
    public const DARK_GRAY = "§8";
    public const GREEN = "§a";
    public const RED = "§c";
    public const YELLOW = "§e";
    public const DARK_BLUE = "§1";
    public const DARK_AQUA = "§3";
    public const DARK_PURPLE = "§5";
    public const GRAY = "§7";
    public const BLUE = "§9";
    public const AQUA = "§b";
    public const LIGHT_PURPLE = "§d";
    public const WHITE = "§f";
}